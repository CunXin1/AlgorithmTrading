from django.apps import AppConfig


class MarketSentimentConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'market_sentiment'
